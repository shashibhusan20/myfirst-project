<div class="container">
<div class="row">
<div class="col-xs-12 col-md-12">
<ul class="nav nav-pills">
  <li class="active"><a data-toggle="pill" href="#home"><strong>Inbox</strong></a></li>
  <li style="margin-left:10px;"><a data-toggle="pill" href="#menu1"><strong>Sentbox</strong></a></li>
  <li style="margin-left:10px;"><a data-toggle="pill" href="#menu2"><strong>Trash</strong></a></li>
  <li style="margin-left:10px;"><a data-toggle="pill" href="#menu3"><strong>Compose</strong></a></li>
  <li style="margin-left:10px;"><a data-toggle="pill" href="#menu4"><strong>Attached Files </strong></a></li>
</ul>

<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
    
    <?php include('inbox-for-front.php'); ?>
	
  </div>
  <div id="menu1" class="tab-pane fade">
    
    <?php include('sent-box-for-front.php'); ?>
  </div>
  <div id="menu2" class="tab-pane fade">
    
    <?php include('trash-for-front.php'); ?>
  </div>
  <div id="menu3" class="tab-pane fade">
    
    <?php include('send-mail-form.php'); ?>
  </div>
  <div id="menu4" class="tab-pane fade">
    
    <?php include('attached-file.php'); ?>
  </div>
</div></div></div></div>