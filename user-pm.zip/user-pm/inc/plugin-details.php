<div class="wrap">
		<h1>Welcome to Geek Mailer Plugin</h1><br/>
		<p>This plugin will work only for logged user.To display on any pages use shortcode ['email_form'] under page's content editor. If You want to use this shortcode please use  do_shortcode(['email_form']) under template file or any other places.<br/><label>Shortcode:[email_form]</p><br/>
<p>To Show Inbox,Sentbox and Trash use Shortcode:[show_inbox_sent_trash] </p>		
		</div>