<table border="0" class="table table-striped">
<tr style="background-color: #dedede;">
<td><strong>To User</strong></td>
<td><strong>From User</strong></td>
<td><strong>Attachment</strong></td>
</tr>
<?php
	
	global $wpdb;
	global $current_user;
	wp_get_current_user();
	$user_id = $current_user->ID; 
	$ToUserMail   = $current_user->user_email;
	$SentBox = $wpdb->prefix.'sentbox_mail';
	$AttachedFile = $wpdb->prefix.'attached_file';
	
	$InboxResult = $wpdb->get_results("SELECT EmailAttach,toUser,fromUser FROM $SentBox INNER JOIN $AttachedFile ON $SentBox.SentId=$AttachedFile.SentId where fromUser='".$ToUserMail."'");
	
	foreach($InboxResult as $InboxData)	
	{?><tr>
	
	<td><?php echo $InboxData->toUser;?></td>
	<td><?php echo $InboxData->fromUser;?></td>
	<td><a href="<?php echo home_url().'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/'.$InboxData->EmailAttach; ?>"><img width="150px;" src="<?php echo home_url().'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/'.$InboxData->EmailAttach; ?>"></a><?php //echo $InboxData->EmailAttach;?></td>
	
	<?php
		
	}
 ?>
</table>