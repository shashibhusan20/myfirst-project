<?php 
echo '<div class="container">';
echo '<div class="row">';
echo '<div class="col-xs-12 col-md-6">';
		echo '<form action="' . deliver_mail() . '" method="post" enctype="multipart/form-data">';
		echo '<p>';
		echo 'Email <br />';
		?>
		<p>
		<select class="locationMultiple form-control" multiple="multiple" name="Userto[]">
		  <?php 
		  global $wpdb;
		  $userTable = $wpdb->prefix.'users';
		  global $current_user;
			wp_get_current_user();
			$user_id = $current_user->ID ; 
		  $Result = $wpdb->get_results("select * from $userTable where ID!='".$user_id."'");
		  foreach($Result as $UserData)
		  {
			?>
		  <option value="<?php echo $UserData->user_email; ?>"><?php echo $UserData->user_email; ?></option>
		  <?php } ?>
		</select>
		</p>
		<?php
		echo '</p>';
		echo '<p>';
		echo '<p>';
		echo 'Subject (required) <br />';
		echo '<input type="text" name="subject" pattern="[a-zA-Z ]+" value="" size="40" />';
		echo '</p>';
		echo '<p>';
		echo 'Your Message (required) <br />';
		$content = '';
		$editor_id = 'message';
		wp_editor( $content, $editor_id );
		echo '</p>';
		echo '<p>';
		echo 'Attached File(required) <br />';
		echo '<input id="upload" name="attached_file[]" type="file" multiple="multiple" />';
		
		echo '</p>';
		echo '<p><input type="submit" name="submit" value="Send"/>&nbsp;<input type="submit" name="" value="Discard"/ style="height:25px;"></p>';
		//echo '<p></p>';
		echo '</form></div></div></div>';
		?>