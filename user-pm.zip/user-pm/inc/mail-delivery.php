<?php
function uploadImage($strEmailId, $arrImageDetalil,$lastid) {
	global $current_user;
	wp_get_current_user();
	$user_id = $current_user->ID ;
	global $wpdb;
	$intCnt = count($arrImageDetalil['name']);
	$intRand = rand();
	for($i=0; $i<$intCnt; $i++) {
	$strImageName = $arrImageDetalil['name'][$i];
	$newFileName = time().$strImageName;
	$file_size = $arrImageDetalil['size'][$i];
	$file_tmp_name    = $arrImageDetalil['tmp_name'][$i];

	$handle = fopen($file_tmp_name, "r");
	$content = fread($handle, $file_size);
	fclose($handle);
	$chkPath = './wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/';

	if(is_dir($chkPath)=="")
	{		
	$ActualPath = mkdir(ABSPATH.'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/',777,true);
	}
	else {

	$ActualPath = $chkPath;
	}

	move_uploaded_file($file_tmp_name, $ActualPath.'/'.$newFileName);

	$RunQuery = $wpdb->query("INSERT INTO `wp_attached_file` (`SentId`, `EmailAttach`) VALUES ('$lastid', '$newFileName')");
}
	 }
if ( isset($_POST['submit'])) 
 {
	 global $current_user;
	
	 //print_r($_FILES);die;
	wp_get_current_user();
	$user_id = $current_user->ID ; 
	$from_email   = $current_user->user_email; //from mail, it is mandatory with 
    $recipient_email = array();
    
    $subject        = $_POST['subject'];
    $message        = $_POST['message'];
	
    global $wpdb;
	$InboxTable = $wpdb->prefix.'inbox_mail';
	$SentBoxTable = $wpdb->prefix.'sentbox_mail';
	/* $file_tmp_name    = $_FILES['attached_file']['tmp_name'];
	$file_name        = $_FILES['attached_file']['name'];
	$file_size        = $_FILES['attached_file']['size'];
    $handle = fopen($file_tmp_name, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
		$chkPath = './wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/';
							
				if(is_dir($chkPath)=="")
				{		
					$ActualPath = mkdir(ABSPATH.'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/',777,true);
				}
				else {
					 
					$ActualPath = $chkPath;
				} */
				
     foreach ($_POST['Userto'] as $val){
		
			$recipient_email = $val;
			
   //move_uploaded_file($file_tmp_name, $ActualPath.'/'.$file_name);
   
    $RunQuery = $wpdb->query("insert into $InboxTable(toUser,fromUser,EmailAdd,EmailSubject,EmailMsg,EmailTime,Status) values('".$recipient_email."','".$from_email."','".$recipient_email."','".$subject."','".$message."',NOW(),'Active')");
	
	$SentBoxMailQ = $wpdb->query("insert into $SentBoxTable(toUser,fromUser,EmailAdd,EmailSubject,EmailMsg,EmailTime,Status) values('".$recipient_email."','".$from_email."','".$recipient_email."','".$subject."','".$message."',NOW(),'Active')");
	
	$lastid = $wpdb->insert_id;
		$strEmailId = $val;
		$arrImageDetalil = $_FILES['attached_file'];
		 
		uploadImage($strEmailId, $arrImageDetalil,$lastid);
		
	/*if($RunQuery && $SentBoxMailQ)
	{
		header('location:'.home_url('mail'));die;
	}*/
	 }
	 
	 
	
	 
	 if($RunQuery && $SentBoxMailQ)
	{
		?>
		<script>
    window.location = '<?php home_url('mail-form'); ?>';
</script>
		<?php die;
	}
	}
	?>