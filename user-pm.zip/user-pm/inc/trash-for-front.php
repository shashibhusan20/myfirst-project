<?php 
if(isset($_POST['submit']) && $_POST['submit']=='Delete')
{
	global $wpdb;
	foreach($_POST['check_list'] as $val)
	{
		$TBlName = $wpdb->prefix.'inbox_mail';
		$wpdb->query("delete from $TBlName where InboxId='".$val."'");
	}
}
?>
<table border="0" class="table table-striped">
<tr style="background-color: #dedede;">
<td><strong>Select</strong></td>
<td><strong>From User</strong></td>
<td><strong>To User</strong></td>
<td><strong>Date</strong></td>
<td><strong>Subject</strong></td>
<td><strong>Message</strong></td>
<td><strong>Attachment</strong></td>

</tr>
<form name="inform" method="post" action="">
<?php
	
	global $wpdb;
	global $current_user;
	wp_get_current_user();
	$user_id = $current_user->ID; 
	$ToUserMail   = $current_user->user_email;
	$InboxTable = $wpdb->prefix.'inbox_mail';
	
	$InboxResult = $wpdb->get_results("select * from $InboxTable where Status='Inactive' and toUser='".$ToUserMail."'");
	foreach($InboxResult as $InboxData)	
	{?><tr>
	<td><input type="checkbox" name="check_list[]" value="<?php echo $InboxData->InboxId;?>"></td>
	<td><?php echo $InboxData->fromUser;?></td>
	<td><?php echo $InboxData->toUser;?></td>
	<td><?php echo $InboxData->EmailTime;?></td>
	<td><?php echo $InboxData->EmailSubject;?></td>
	<td><?php echo $InboxData->EmailMsg;?></td>
	<td><a href="<?php echo home_url().'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/'.$InboxData->EmailAttach; ?>"><img src="<?php echo home_url().'/wp-content/uploads/'.date('Y').'/'.'mail'.'/'.$user_id.'/'.$InboxData->EmailAttach; ?>"></a><?php //echo $InboxData->EmailAttach;?></td>
	
	<?php
		
	}
 ?>
 
 </table><input type="submit" name="submit" value="Delete">
 </form>