<div class="wrap">
<h1>
Sent Mail List	
</h1>
<h2 class="screen-reader-text">Filter users list</h2>
<?php global $wpdb;
global $wp_rewrite;
$TBlName = $wpdb->prefix.'inbox_mail';
$rows_per_page = 5;
$current = isset($_GET['paged']) ? $_GET['paged'] : 1;
$results = $wpdb->get_results( "SELECT * FROM $TBlName" );
 $pagination_args = array(
 'base' => @add_query_arg('paged','%#%'),
 'format' => '',
 'total' => ceil(sizeof($results)/$rows_per_page),
 'current' => $current,
 'show_all' => false,
 'type' => 'plain'
);

if( !empty($wp_query->query_vars['s']) )
 $pagination_args['add_args'] = array('s'=>get_query_var('s'));



$start = ($current - 1) * $rows_per_page;
$end = $start + $rows_per_page;
$end = (sizeof($results) < $end) ? sizeof($results) : $end;

?>
<form method="get">
<p class="search-box">
	<label class="screen-reader-text" for="user-search-input">Search Mails:</label>
	<input type="search" id="user-search-input" name="s" value="">
	<input type="submit" id="search-submit" class="button" value="Search Mails"></p>

<input type="hidden" id="_wpnonce" name="_wpnonce" value="a94e913dec"><input type="hidden" name="_wp_http_referer" value="">	
<h2 class="screen-reader-text">Users list</h2><table class="wp-list-table widefat fixed striped users">
	<thead>
	<tr>
		<td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label><input id="cb-select-all-1" type="checkbox"></td><th scope="col" id="username" class="manage-column column-username column-primary sortable desc"><a href=""><span>User To</span><span class="sorting-indicator"></span></a></th><th scope="col" id="name" class="manage-column column-name">From User</th><th scope="col" id="email" class="manage-column column-email sortable desc"><a href=""><span>Email</span><span class="sorting-indicator"></span></a></th><th scope="col" id="role" class="manage-column column-role">Subject</th><th scope="col" id="posts" class="manage-column column-posts num">Message</th>	</tr>
	</thead>

	<tbody id="the-list" data-wp-lists="list:user">
	
	<?php global $wpdb;
	
	/*$TBlName = $wpdb->prefix.'sent_mail';
	$ResultData = $wpdb->get_results("select toUser,fromUser,EmailAdd,EmailSubject,EmailMsg from $TBlName");
	foreach($ResultData as $value)
	{*/
	?>
	<?php
$result = $wpdb->get_results( "SELECT * FROM $TBlName  LIMIT $start, $rows_per_page" );
for ($i=$start;$i < $end ;++$i ) {
 @$row = $result[$i];

?>
	<tr id="user-1"><th scope="row" class="check-column">
	<label class="screen-reader-text" for="user_1">Select admin</label>
	<input type="checkbox" name="users[]" id="user_1" class="administrator" value="1"></th>
	<td class="username column-username has-row-actions column-primary" data-colname="Username">
	
	<strong><a href=""><?php echo $row->toUser ;?></a></strong><br>
	<div class="row-actions">
	<span class="edit"><a href="">Trash</a></span>
	</div>
	<button type="button" class="toggle-row">
	<span class="screen-reader-text">Show more details</span>
	</button></td>
	<td class="name column-name" data-colname="Name"><?php echo $row->fromUser ;?> </td>
	<td class="email column-email" data-colname="Email"><a href=""><?php echo $row->EmailAdd ;?></a></td>
	<td class="role column-role" data-colname="Role"><?php echo $row->EmailSubject ;?></td>
	<td class="posts column-posts num" data-colname="Posts"><a href="" class="edit"><span aria-hidden="true"><?php echo $row->EmailMsg ;?></span><span class="screen-reader-text">1 post by this author</span></a>
	</td>
	</tr>
	<?php  }  ?>
	
		</tbody>

	<tfoot>
	<tr>
		<td class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2">Select All</label><input id="cb-select-all-2" type="checkbox"></td><th scope="col" class="manage-column column-username column-primary sortable desc"><a href=""><span>Username</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-name">Name</th><th scope="col" class="manage-column column-email sortable desc"><a href=""><span>Email</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-role">Role</th><th scope="col" class="manage-column column-posts num">Posts</th>	</tr>
	</tfoot>

</table>
<?php echo '<strong>Pages</strong>'.paginate_links($pagination_args); ?>	
</form>

<br class="clear">
</div>