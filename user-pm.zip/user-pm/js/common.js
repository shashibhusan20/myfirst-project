$(document).ready(function () {
$.fn.select2.defaults.set("theme", "bootstrap");
$(".locationMultiple").select2({
	 width: null
})
});
		