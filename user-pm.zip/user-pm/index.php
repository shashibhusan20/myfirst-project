<?php
/*
Silence is golden
*/
?>