<?php
/*
Plugin Name:User PM
Description:This is the mailling plugin for logged user
Author:Geekassured
Version: 1.0.0
Licence:GPL
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
/*Get current user info*/
/* Creating table during plugin installation if not exist*/
function create_geek_user_mail_table()
	{
		global $wpdb, $wp_version;
		
		$InboxMail = $wpdb->prefix . "inbox_mail";
		
		$SentBoxMail = $wpdb->prefix . "sentbox_mail";
		
		$AttachedTable  = $wpdb->prefix . "attached_file";
		
		$wpdb->query("CREATE TABLE IF NOT EXISTS ".$InboxMail."(
		InboxId int(10) not null auto_increment,
		toUser text not null,
		fromUser text not null,
		EmailAdd longtext not null,
		EmailSubject text not null,
		EmailMsg longtext not null,
		EmailAttach varchar(250),
		EmailTime datetime not null default '0000-00-00 00:00:00',
		Status varchar(50) not null,
		primary key(InboxId))");
		
		$wpdb->query("CREATE TABLE IF NOT EXISTS ".$SentBoxMail."(
		SentId int(10) not null auto_increment,
		toUser text not null,
		fromUser text not null,
		EmailAdd longtext not null,
		EmailSubject text not null,
		EmailMsg longtext not null,
		EmailAttach varchar(250),
		EmailTime datetime not null default '0000-00-00 00:00:00',
		Status varchar(50) not null,
		primary key(SentId))");
		
		$wpdb->query("CREATE TABLE IF NOT EXISTS ".$AttachedTable."(
		AttId int(10) not null auto_increment,
		InboxId varchar(100) not null,
		SentId varchar(100) not null,
		EmailAttach varchar(250),
		primary key(AttId))");
		file_put_contents(__DIR__.'/my_loggg.txt', ob_get_contents());
		}
		
register_activation_hook(__FILE__,'create_geek_user_mail_table');
add_action('admin_menu', 'my_plugin_menu');
/* Add menu and submenu */
function my_plugin_menu() 
	{
		add_menu_page('Inbox', 'Geek User Mail', 'manage_options', 'my-top-level-slug' ,'InboxMail','');
		
		add_submenu_page('my-top-level-slug', 'Sent Mail', 'Sent Mail', 'manage_options', 'Sent','DisplaySentMail');
		
		add_submenu_page('my-top-level-slug', 'Plugin Details', 'Plugin Details', 'manage_options', 'Details','PluginDetails');
	
	}
/*Add js and css in plugin*/

add_action('init', 'register_script');

function register_script() 
	{
	
		wp_register_script( 'custom_jquery', plugins_url('/js/jquery-2.2.0.min.js', __FILE__), array('jquery'), '2.2.0',true );
		
		wp_register_script( 'custom_jquery2', plugins_url('/js/bootstrap.min.js', __FILE__), false, '1.0.0', 'all',true);
		
		wp_register_script( 'custom_jquery1', plugins_url('/js/select2.min.js', __FILE__), false, '1.0.0', 'all',true);
		
		
		
		wp_register_script( 'custom_jquery_common', plugins_url('/js/common.js', __FILE__), false, '', 'all',true);
		
		wp_register_style( 'new_style1', plugins_url('/css/select2.min.css', __FILE__), false, '1.0.0', 'all',true);
		
		wp_register_style( 'new_style', plugins_url('/css/bootstrap.min.css', __FILE__), false, '1.0.0', 'all',true);
		
		
		wp_register_style( 'select2-bootstrap', plugins_url('/css/select2-bootstrap.css', __FILE__), false, '1.0.0', 'all',true);
}
add_action('wp_enqueue_scripts', 'enqueue_style');

function enqueue_style()
 {
	
    wp_enqueue_script('custom_jquery');
	wp_enqueue_script('custom_jquery2');
	wp_enqueue_script('custom_jquery_common');
	wp_enqueue_script('custom_jquery1');
	wp_enqueue_style( 'new_style1' );
    wp_enqueue_style( 'new_style' );
    wp_enqueue_style( 'select2-bootstrap' );
 }

/*end of adding js and css in the plugin*/	
	
function PluginDetails()
	{
		include('inc/plugin-details.php');
	}
function InboxMail()
	{
	 include('inc/inbox-for-admin.php');
	}

function DisplaySentMail()
	{
		include('inc/display-sent-mail.php');
	}

function send_mail_form() 
	{
		
		include('inc/send-mail-form.php');
	}
function send_mail_error_message()
	{
	 echo '<h1 style="text-align:center">'."You arn't login please login first".'</h1>';		
	}

function deliver_mail() 
	{
		include('inc/mail-delivery.php');
	}
/*Generate shortcode if user logged in*/
function display_inbox_sent_and_trash()
{
	if(is_user_logged_in())
{
	include('inc/allmaildetails.php');
	
}else{
	
	echo '<h1 style="text-align:center">'."You arn't login please login first".'</h1>';
}
}	
add_shortcode( 'show_inbox_sent_trash', 'display_inbox_sent_and_trash' );
?>
